__version__ = '20211012'

if __name__ == '__main__':
    print(__version__)
